export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyC3M05Ma0Wwu4MiyLuVu7nxIKRWNgxqKd8",
    authDomain: "umg-compte.firebaseapp.com",
    databaseURL: "https://umg-compte.firebaseio.com",
    projectId: "umg-compte",
    storageBucket: "umg-compte.appspot.com",
    messagingSenderId: "214111608543"
  }
};
