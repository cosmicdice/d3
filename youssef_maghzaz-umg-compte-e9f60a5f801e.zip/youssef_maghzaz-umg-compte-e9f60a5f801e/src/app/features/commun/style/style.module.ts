import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Angular2FontawesomeModule } from 'angular2-fontawesome/angular2-fontawesome';

@NgModule({
  imports: [
    CommonModule,
    Angular2FontawesomeModule
  ],
  declarations: []
})
export class StyleModule { }
