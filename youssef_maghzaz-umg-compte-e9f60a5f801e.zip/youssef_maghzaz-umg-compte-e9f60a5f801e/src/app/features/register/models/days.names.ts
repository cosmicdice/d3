export const DAYS = [
  {
    name: "lundi"
  },
  {
    name: "mardi"
  },
  {
    name: "mercredi"
  },
  {
    name: "jeudi"
  },
  {
    name: "vendredi"
  },
  {
    name: "samedi"
  },
  {
    name: "dimanche"
  }
];
