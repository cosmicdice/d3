export const COURSES = [
  {
    name: "arabic",
    id: 1
  },
  {
    name: "coran",
    id: 2
  }
];
