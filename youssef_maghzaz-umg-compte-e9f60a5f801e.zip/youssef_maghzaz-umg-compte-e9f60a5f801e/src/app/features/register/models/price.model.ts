export const PRICE = [
  {
    session: 0,
    price: 0,
    supplement: 0
  },
  {
    session: 1,
    price: 155,
    supplement: 0
  },
  {
    session: 2,
    price: 92.5,
    supplement: 10
  },
  {
    session: 3,
    price: 79,
    supplement: 0
  },
  {
    session: 4,
    price: 67.5,
    supplement: 0
  },
  {
    session: 5,
    price: 60,
    supplement: 0
  }
];

export const PRICE_OPTION = {
  city: 10,
  umg: -10,
  familly: -5
};
