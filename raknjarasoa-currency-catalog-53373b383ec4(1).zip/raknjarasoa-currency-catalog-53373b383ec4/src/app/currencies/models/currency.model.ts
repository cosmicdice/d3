export class Currency {
  code: string;
  name: string;
  symbol: string;
}
