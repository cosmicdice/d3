export const environment = {
  production: true,
  API_ENDPOINT: 'https://restcountries.eu/rest/v2'
};
